#include<stdio.h>
int main(){
	int senha;
	
	do{
		printf("Digite a senha: ");
		scanf("%d", &senha);
	}while (senha != 123);
	
	printf("\nSenha Correta!\n");
	printf("\nAcesso LIberado\n");
	
	return 0;
}
