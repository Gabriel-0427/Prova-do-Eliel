#include<stdio.h>
int main(){
	float num1, num2, resultado;
	int opcao;
	
	printf("Digite o primeiro numero: ");
	scanf("%f", &num1);
	
	printf("Digite o segundo numero: ");
	scanf("%f", &num2);
	
	printf("\nEscolha uma Operacao:\n");
	printf("1 - Soma\n");
	printf("2 - Subtracao\n");
	printf("3 - Divisao\n");
	printf("4 - Multiplicacao\n");
	printf("\nDigite sua Opcao: ");
	scanf("%d", &opcao);
			
	switch(opcao){
		case 1:
			resultado = num1 + num2;
			printf("\nResultado: %.2f\n", resultado);
			break;
					
		case 2:
			resultado = num1 - num2;
			printf("\nResultado: %.2f\n", resultado);
			break;
					
		case 3:
			resultado = num1 * num2;
			printf("\nResultado: %.2f\n", resultado);
			break;
					
		case 4:
			if (num2 != 0){
				resultado = num1 / num2;
				printf("\nResultado: %.2f\n", resultado);
			}else{
				printf("\nErro: nao e possivel dividir por zero.\n");
				}
				break;
	default:
		printf("\nOpcao Invalida!\n");
		break;
				}
				
	return 0;
}
